module.exports = (app) => {
    const isProd = process.env.NODE_ENV === 'production';
    if (isProd) {
        require('./prodMiddlewares')(app);
    } else {
        require('./devMiddlewares')(app);
    }
};