module.exports = {
  ignore: [
    /\/core-js/,
    /webpack\/buildin/
  ],
  overrides: [{
    test: './node_modules'
  }],
  sourceType: 'unambiguous',
  presets: [
    [
      '@babel/preset-env',
      {
        modules: false,
        /* false 时 此时不对 polyfill 做操作*/
        /* entry 时 根据配置的浏览器兼容，引入浏览器不兼容的 polyfill。*/
        /* usage 时 会根据配置的浏览器兼容，以及你代码中用到的 API 来进行 polyfill，实现了按需添加。*/
        /* Babel 7.3 之前，useBuiltIns: usage 不稳定且不是足够可靠 */
        /* usage 没成功过，调试了一个礼拜还版本换配置，换其他包都没成功过，暂时用 entry */
        /* 具体说明文档 https://github.com/zloirock/core-js/blob/master/docs/zh_CN/2019-03-19-core-js-3-babel-and-a-look-into-the-future.md#babelpreset-env */
        /* 开发时运行的配置 */
        useBuiltIns: 'entry',
        corejs: 3,
        /* 文档说明是这样配置，但实际如此配置项目无法运行。
        但是打包用这个按需加载的配置，打出来的包却没问题
        useBuiltIns: 'usage',
        corejs: {
          version: 3,
          proposals: true
        },*/
        targets: {
          "chrome": "58",
          "ie": "11"
        }
      }
    ],
    '@babel/preset-react',
    '@babel/preset-typescript'
  ],
  plugins: [
    'react-hot-loader/babel',
    '@babel/plugin-proposal-class-properties',
    '@babel/plugin-syntax-dynamic-import',
    '@babel/plugin-proposal-optional-chaining',
    ['import', {
      'libraryName': 'antd',
      'libraryDirectory': 'es',
      'style': true
    }],
    ['transform-imports', {
      'react-router': {
        'transform': 'react-router/${member}',
        'preventFullImport': true
      },
      'lodash': {
        'transform': 'lodash/${member}',
        'preventFullImport': true
      }
    }],
    ['react-intl', {
      'extractFromFormatMessageCall': true,
      'idInterpolationPattern': '[sha512:contenthash:base64:6]',
      'ast': true
    }
    ]
  ],
  env: {
    production: {
      only: ['app', 'libs', 'share'],
      plugins: [
        'lodash',
        'transform-react-remove-prop-types',
        '@babel/plugin-transform-react-constant-elements'
      ]
    },
    test: {
      plugins: [
        '@babel/plugin-transform-modules-commonjs',
        'dynamic-import-node'
      ]
    }
  }
}
