import 'intersection-observer'


import React from 'react'
import ReactDOM from 'react-dom'
import { Provider } from 'react-redux'
import { ConnectedRouter } from 'connected-react-router'
import history from 'utils/history'

import App from 'containers/App'

import { ConfigProvider } from 'antd'
import zh_CN from 'antd/es/locale/zh_CN'
import LanguageProvider from 'containers/LanguageProvider'
import { translationMessages } from './i18n'
import moment from 'moment'
import 'moment/src/locale/zh-cn'

moment.locale('zh-cn')

import '!file-loader?name=[name].[ext]!./favicon.ico'

import configureStore from './configureStore'


const initialState = {}
const store = configureStore(initialState, history)
const MOUNT_NODE = document.getElementById('app')

const render = (messages) => {
  ReactDOM.render(
    <Provider store={store}>
      <LanguageProvider messages={messages}>
        <ConfigProvider locale={zh_CN}>
          <ConnectedRouter history={history}>
            <App/>
          </ConnectedRouter>
        </ConfigProvider>
      </LanguageProvider>
    </Provider>,
    MOUNT_NODE
  )
}
// @ts-ignore
if (module.hot) {
  // @ts-ignore
  module.hot.accept(['./i18n', 'containers/App'], () => {
    ReactDOM.unmountComponentAtNode(MOUNT_NODE)
    render(translationMessages)
  })
}

interface IWindow extends Window {
  Intl: any
  __REACT_DEVTOOLS_GLOBAL_HOOK__: any
}

declare const window: IWindow

if (!window.Intl) {
  (new Promise((resolve) => {
    resolve(import('intl'))
  }))
    .then(() => Promise.all([
      // @ts-ignore
      import('intl/locale-data/jsonp/en.js')
    ]))
    .then(() => render(translationMessages))
    .catch((err) => {
      throw err
    })
} else {
  render(translationMessages)
}

// Install ServiceWorker and AppCache in the end since
// it's not most important operation and if main code fails,
// we do not want it installed
if (process.env.NODE_ENV === 'production') {
  // disable react developer tools in production
  if (window.__REACT_DEVTOOLS_GLOBAL_HOOK__) {
    window.__REACT_DEVTOOLS_GLOBAL_HOOK__.inject = () => void 0
  }
}
