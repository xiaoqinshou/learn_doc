const os = require('os');
const path = require('path');
const webpack = require('webpack');
// 多线程打包优化
// 由于HappyPack 对file-loader、url-loader 支持的不友好, 所以这两个loader不交给happyPack处理
const HappyPack = require('happypack');
// 获取线程池，线程池大小为当前cpu 核心数
const happyThreadPool = HappyPack.ThreadPool({size: os.cpus().length})
// 打包时所引用的主题CSS
const overrideLessVariables = require('../override/lessVariables');
// alias 路径插件
const TsconfigPathsPlugin = require('tsconfig-paths-webpack-plugin');

module.exports = options => ({
    mode: options.mode,
    entry: options.entry,
    devtool: options.devtool,
    target: 'web', // Make web variables accessible to webpack, e.g. window
    performance: options.performance || {},
    optimization: options.optimization,
    output: Object.assign(
        {
            path: path.resolve(process.cwd(), 'build'),
            publicPath: '/'
        },
        options.output
    ),
    resolve: {
        modules: ['node_modules', 'app'],
        extensions: ['.js', '.jsx', '.ts', '.tsx', '.react.js'],
        mainFields: ['browser', 'jsnext:main', 'main'],
        /* 引用tsconfig-paths-webpack-plugin插件 */
        plugins: [new TsconfigPathsPlugin()]
        /* 不引用，使用原生的需要再次配置alias
        alias: {
            'react-resizable': path.resolve(process.cwd(), 'libs/react-resizable'),
            app: path.resolve(process.cwd(), 'app'),
            share: path.resolve(process.cwd(), 'share'),
            libs: path.resolve(process.cwd(), 'libs'),
            assets: path.resolve(process.cwd(), 'app/assets')
            // fonts: path.resolve(process.cwd(), 'app/assets/fonts')
        }*/
    },
    module: {
        rules: [
            {
                test: /\.tsx?$/,
                exclude: /node_modules/,
                use: 'happypack/loader?id=typescript'
            },
            {
                test: /\.js?$/,
                use: 'happypack/loader?id=js'
            },
            {
                test: /\.css$/,
                include: /node_modules|libs/,
                use: 'happypack/loader?id=css'
            },
            {
                test: /\.css$/,
                include: [/app[\\\/]assets/],
                use: 'happypack/loader?id=assets-css'
            },
            {
                test: /\.less$/,
                include: /node_modules/,
                use: 'happypack/loader?id=less'
            },
            {
                test: /\.less$/,
                exclude: /node_modules/,
                use: 'happypack/loader?id=assets-less'
            },
            /*
            // 未引用 happy pack 时的打包方式
            {
                test: /\.css$/,
                include: /node_modules|libs/,
                use: ['style-loader/url', {
                    loader: 'file-loader',
                    options: {
                        name: '[path][name].[ext]',
                    },
                }, 'css-loader']
            },
            {
                test: /\.less$/,
                include: [/app[\\\/]components/],
                use: ['style-loader/url', {
                    loader: 'file-loader',
                    options: {
                        name: '[path][name].[ext]',
                    },
                }, {
                    loader: 'css-loader',
                    options: {
                        sourceMap: true,
                        getLocalIdent: (context, _, localName) => {
                            if (context.resourcePath.includes('node_modules')) {
                                return localName;
                            }
                            const match = context.resourcePath.match(/app(.*)/);
                            if (match && match[1]) {
                                const antdProPath = match[1].replace('.less', '');
                                const arr = slash(antdProPath)
                                    .split('/')
                                    .map(a => a.replace(/([A-Z])/g, '-$1'))
                                    .map(a => a.toLowerCase());
                                return `udnt-${arr.join('-')}-${localName}`.replace(/--/g, '-');
                            }
                            return localName;
                        },
                    },
                },
                    'postcss-loader', {
                        loader: 'less-loader',
                        options: {
                            sourceMap: true,
                            javascriptEnabled: true
                        }
                    }
                ]
            },*/
            {
                test: /\.html$/,
                use: 'html-loader'
            },
            {
                test: /\.(eot|otf|ttf|woff|woff2)$/,
                use: 'file-loader'
            },
            {
                test: /\.(jpe?g|png|gif)$/,
                use: [
                    {
                        loader: 'url-loader',
                        options: {
                            limit: 10 * 1024
                        }
                    },
                    {
                        loader: 'image-webpack-loader',
                        options: {
                            mozjpeg: {
                                progressive: true,
                                quality: 65
                            },
                            optipng: {
                                enabled: false,
                            },
                            pngquant: {
                                quality: [0.65, 0.90],
                                speed: 4
                            },
                            gifsicle: {
                                interlaced: false,
                            },
                            webp: {
                                quality: 75
                            }
                        }
                    }
                ]
            },
            {
                test: /\.(mp4|webm)$/,
                use: {
                    loader: 'url-loader',
                    options: {
                        limit: 10000
                    }
                }
            }
        ]
    },
    plugins: options.plugins.concat([
        // Always expose NODE_ENV to webpack, in order to use `process.env.NODE_ENV`
        // inside your code for any environment checks; UglifyJS will automatically
        // drop any unreachable code.
        new webpack.DefinePlugin({
            'process.env': {
                NODE_ENV: JSON.stringify(process.env.NODE_ENV)
            }
        }),
        new webpack.ContextReplacementPlugin(/^\.\/locale$/, (context) => {
            if (!/\/moment\//.test(context.context)) return;

            Object.assign(context, {
                regExp: /^\.\/\w+/,
                request: '../../locale', // resolved relatively
            });
        }),
        new HappyPack({
            id: 'typescript',
            loaders: options.tsLoaders,
            threadPool: happyThreadPool,
            verbose: true
        }),
        new HappyPack({
            id: 'js',
            loaders: ['babel-loader'],
            threadPool: happyThreadPool,
            verbose: true
        }),
        new HappyPack({
            id: 'css',
            loaders: ['style-loader', 'css-loader'],
            threadPool: happyThreadPool,
            verbose: true
        }),
        new HappyPack({
            id: 'assets-css',
            loaders: ['style-loader', {
                loader: 'css-loader',
                options: {
                    sourceMap: true,
                    getLocalIdent: (context, _, localName) => {
                        if (context.resourcePath.includes('node_modules')) {
                            return localName;
                        }
                        const match = context.resourcePath.match(/app(.*)/);
                        if (match && match[1]) {
                            const antdProPath = match[1].replace('.less', '');
                            const arr = slash(antdProPath)
                                .split('/')
                                .map(a => a.replace(/([A-Z])/g, '-$1'))
                                .map(a => a.toLowerCase());
                            return `udnt-${arr.join('-')}-${localName}`.replace(/--/g, '-');
                        }
                        return localName;
                    },
                },
            },
                'postcss-loader',
            ],
            threadPool: happyThreadPool,
            verbose: true
        }),
        new HappyPack({
            id: 'less',
            loaders: [
                'style-loader',
                'css-loader',
                {
                    loader: 'less-loader',
                    /* 6.0.0 以下的写法
                    options: {
                        sourceMap: true,
                        javascriptEnabled: true,
                        modifyVars: overrideLessVariables
                    }*/
                    /* 6.0.0 以上的写法 */
                    options: {
                        lessOptions: {
                            javascriptEnabled: true,
                            modifyVars: overrideLessVariables
                        },
                        sourceMap: true,
                    }
                }
            ],
            threadPool: happyThreadPool,
            verbose: true
        }),
        new HappyPack({
            id: 'assets-less',
            loaders: [
                'style-loader', {
                    loader: 'css-loader',
                    options: {
                        modules: true,
                        importLoaders: 1,
                        sourceMap: true,
                        getLocalIdent: (context, _, localName) => {
                            if (context.resourcePath.includes('node_modules')) {
                                return localName;
                            }
                            const match = context.resourcePath.match(/app(.*)/);
                            if (match && match[1]) {
                                const antdProPath = match[1].replace('.less', '');
                                const arr = slash(antdProPath)
                                    .split('/')
                                    .map(a => a.replace(/([A-Z])/g, '-$1'))
                                    .map(a => a.toLowerCase());
                                return `udnt-${arr.join('-')}-${localName}`.replace(/--/g, '-');
                            }
                            return localName;
                        },
                    },
                },
                'postcss-loader', {
                    loader: 'less-loader',
                    options: {
                        sourceMap: true,
                        javascriptEnabled: true
                    }
                },
            ],
            threadPool: happyThreadPool,
            verbose: true
        }),
    ]),
});