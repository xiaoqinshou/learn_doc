# getGuessSearch(/path/getGuessSearch)
http://127.0.0.1:8092/path/getGuessSearch?q=赵&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=成龙&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=变形金刚&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=z&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=cl&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=CL&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=bxjg&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=BXJG&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=cl&count=300

# getnewtopn(/path/getnewtopn)
http://127.0.0.1:8092/path/getnewtopn?typeid=005&count=100&sdonly=0&start=0
http://127.0.0.1:8092/path/getnewtopn?typeid=005&count=30&sdonly=0&start=0
http://127.0.0.1:8092/path/getnewtopn?typeid=005&count=30&sdonly=0&start=0
http://127.0.0.1:8092/path/getnewtopn?typeid=001&count=100&sdonly=0&start=0

# getsimilaritems(/path/getsimilaritems)
http://127.0.0.1:8092/path/getsimilaritems?mc=monggotv000000109854059327524518
http://127.0.0.1:8092/path/getsimilaritems?mc=monggotv000000109854059327524518&count=2

# gettopn(/path/gettopn)
http://127.0.0.1:8097/path/gettopn?type=v&sdonly=0&count=5
http://127.0.0.1:8097/path/gettopn?type=c&sdonly=0&count=5
http://127.0.0.1:8095/path/gettopn?type=v&sdonly=0&count=1

# getuserrecmd(/path/getuserrecmd)
http://127.0.0.1:8092/path/getuserrecmd?userid=06604334138
http://127.0.0.1:8092/path/getuserrecmd?userid=06604334138
http://127.0.0.1:8092/path/getuserrecmd

# hotsearchtopn(/path/hotsearchtopn)
http://127.0.0.1:8092/path/hotsearchtopn?searchkey=d_005_0
http://127.0.0.1:8092/path/hotsearchtopn?type=d&sdonly=0&column=001
http://127.0.0.1:8092/path/hotsearchtopn?type=d&sdonly=0
http://127.0.0.1:8097/path/hotsearchtopn?column=001&sdonly=1&type=d&count=2
http://127.0.0.1:8097/path/hotsearchtopn?column=002&sdonly=0&type=d&count=2
http://127.0.0.1:8097/path/hotsearchtopn?sdonly=1&type=d&count=2
http://127.0.0.1:8092/path/hotsearchtopn?column=001&type=d

# multisearch(/path/multisearch)
http://127.0.0.1:8097/path/multisearch?count=5&personName=成龙
http://127.0.0.1:8097/path/multisearch?count=5&personName=望子成龙
http://127.0.0.1:8097/path/multisearch?count=5&title=望子成龙
http://127.0.0.1:8097/path/multisearch?count=5&title=成龙
http://127.0.0.1:8097/path/multisearch?count=5&title=成龙&column=002,004
http://127.0.0.1:8097/path/multisearch?count=5&directors=成龙
http://127.0.0.1:8097/path/multisearch?count=5&directors=cl
http://127.0.0.1:8097/path/multisearch?count=5&directors=CL
http://127.0.0.1:8097/path/multisearch?count=5&casts=成龙
http://127.0.0.1:8097/path/multisearch?count=5&personName=cl
http://127.0.0.1:8097/path/multisearch?count=5&directors=CL
http://127.0.0.1:8097/path/multisearch?count=5&personName=wzcl
http://127.0.0.1:8097/path/multisearch?count=5&personName=zrf
http://127.0.0.1:8097/path/multisearch?count=5&personName=ZRF
http://127.0.0.1:8097/path/multisearch?count=5&personName=zym
http://127.0.0.1:8097/path/multisearch?count=5&title=zrf
http://127.0.0.1:8097/path/multisearch?count=5&directors=zrf
http://127.0.0.1:8097/path/multisearch?count=5&casts=zrf
http://127.0.0.1:8097/path/multisearch?count=5&title=ZRF
http://127.0.0.1:8097/path/multisearch?count=5&directors=ZRF
http://127.0.0.1:8097/path/multisearch?count=5&casts=ZRF
http://127.0.0.1:8097/path/multisearch?count=5&personName=张艺谋
http://127.0.0.1:8097/path/multisearch?count=5&title=张艺谋
http://127.0.0.1:8097/path/multisearch?count=5&directors=张艺谋
http://127.0.0.1:8097/path/multisearch?count=5&directors=zym
http://127.0.0.1:8097/path/multisearch?count=5&directors=ZYM
http://127.0.0.1:8097/path/multisearch?count=5&casts=张艺谋
http://127.0.0.1:8097/path/multisearch?count=5&personName=张艺谋&title=成龙
http://127.0.0.1:8097/path/multisearch?count=5&personName=张艺谋&directors=成龙
http://127.0.0.1:8097/path/multisearch?count=5&personName=张艺谋&casts=成龙
http://127.0.0.1:8097/path/multisearch?count=5&sortMode=RDPVC
http://127.0.0.1:8097/path/multisearch?count=5&personName=杰金斯&sortMode=RDPUC
http://127.0.0.1:8097/path/multisearch?count=5&title=神奇&sortMode=RDPUC
http://127.0.0.1:8097/path/multisearch?count=5&title=神奇
http://127.0.0.1:8097/path/multisearch?count=5&dynamicTags=犯罪&sortMode=RDPUC
http://127.0.0.1:8097/path/multisearch?count=5&dynamicTags=犯罪,VIP&sortMode=RDPUC
http://127.0.0.1:8097/path/multisearch?count=5&title=nba最前线
http://127.0.0.1:8097/path/multisearch?count=5&title=NBA最前线
http://127.0.0.1:8097/path/multisearch?count=5&virtualPackageIds=A,B
http://127.0.0.1:8097/path/multisearch?count=5&dynamicTags=犯罪&sortMode=RDPUC&virtualPackageIds=D,C,F
http://127.0.0.1:8097/path/multisearch?count=5&virtualPackageIds=A,B&feeType=1
http://127.0.0.1:8097/path/multisearch?count=5&dynamicTags=犯罪&sortMode=RDPUC&virtualPackageIds=D,C,F,A&feeType=0

# recommend(/api/v1/servicepath/schedule/recommend)
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend?code=00000001000000070000000116343371&recommentType=ALL&recommentTime=20210724140000
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend?count=40&code=00000001000000070000000116343371&recommentType=TVOD&recommentTime=20210724140000
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend?count=40&code=00000001000000070000000116343371&recommentType=LIVETV&recommentTime=20210723140000
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend?count=40&code=00000001000000070000000116343371&recommentType=LIVETV&recommentTime=20210724140000
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend?count=40&code=00000001000000070000000116343371&recommentType=BOOKING&recommentTime=20210724140000
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend?count=40&code=00000001000000070000000116115967&recommentType=ALL&recommentTime=20210720210000
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend?count=40&code=00000001000000070000000116115967&recommentType=TVOD&recommentTime=20210720210000
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend?count=40&code=00000001000000070000000116115967&recommentType=LIVETV&recommentTime=20210720210000
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend?count=40&code=00000001000000070000000116115967&recommentType=BOOKING&recommentTime=20210720210000

# search(/path/search)
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&sortMode=RDPUC
http://127.0.0.1:8092/path/search?count=5&q=周润发
http://127.0.0.1:8092/path/search?count=5&q=周润发&column=029,002,001
http://127.0.0.1:8092/path/search?count=5&q=zyf
http://127.0.0.1:8092/path/search?count=5&q=ZYF
http://127.0.0.1:8092/path/search?count=5&q=金刚
http://127.0.0.1:8092/path/search?count=5&q=nba最前线
http://127.0.0.1:8092/path/search?count=5&q=NBA最前线
http://127.0.0.1:8092/path/search?count=5&q=jg
http://127.0.0.1:8092/path/search?count=5&q=JG
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&q=神奇
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&q=神奇&sortMode=RDPVS
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&dynamicTags=犯罪
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&dynamicTags=犯罪,VIP
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&dynamicTags=犯罪,VIP,0006
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&dynamicTags=
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&dynamicTags=犯罪&q=cl
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&category=/category_99948209
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&category=/category_99948209,/category_02955940/category_93858573/category_31394946
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&category=/category_02955940
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&category=/category_02955940&q=cl
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&category=/category_31394946
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&category=/category_02955940&dynamicTags=犯罪
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&category=/category_02955940&dynamicTags=犯罪,VIP
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&category=/category_02955940&dynamicTags=犯罪&sortMode=RDPVC
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&category=/category_02955940&dynamicTags=犯罪,VIP&sortMode=RDPVC
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&category=/category_02955940&dynamicTags=犯罪&sortMode=RDPVC&q=cl
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&category=/category_02955940&dynamicTags=犯罪,VIP&sortMode=RDPVC&q=成
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&category=/category_02955940&sortMode=RDPVC&q=成龙
http://127.0.0.1:8092/path/search?cacheEnabled=false&clearEnabled=true&q=布莱特-拉特纳&sortMode=RDPVC&count=100
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&virtualPackageIds=A,B
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&category=/category_02955940&sortMode=RDPVC&q=成龙&virtualPackageIds=A,B
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&feeType=1
http://127.0.0.1:8092/path/search?count=5&cacheEnabled=false&clearEnabled=true&category=/category_02955940&sortMode=RDPVC&q=成龙&virtualPackageIds=A,B&feeType=0


# search-history(/api/v1/servicepath/video/search-history)
http://127.0.0.1:8092/api/v1/servicepath/video/search-history/add?code=02000022000000012017041099262300&hdFlag=0&type=CODE&userId=59803030059
http://127.0.0.1:8092/api/v1/servicepath/video/search-history/add?code=成龙&type=KEY&userId=59803030059
http://127.0.0.1:8092/api/v1/servicepath/video/search-history/code?count=100&start=0&userId=59803030059&count=2
http://127.0.0.1:8092/api/v1/servicepath/video/search-history/key?count=100&start=0&userId=59803030059&count=2
http://127.0.0.1:8092/api/v1/servicepath/video/search-history/reset?userId=59803030059
http://127.0.0.1:8092/api/v1/servicepath/video/search-history/add?code=成龙&userId=59803030059
http://127.0.0.1:8092/api/v1/servicepath/video/search-history/add?code=02000022000000012017041099262300&type=CODE&userId=59803030059
http://127.0.0.1:8092/api/v1/servicepath/video/search-history/add?code=22000022000000012017041099262300&type=CODE&userId=59803030059

# getchannelrecmdvod(/path/getchannelrecmdvod)
http://127.0.0.1:8092/path/getchannelrecmdvod

# getlastesttopn(/path/getlastesttopn)
http://127.0.0.1:8092/path/getlastesttopn

# getmoviesbyname(/path/getmoviesbyname)
http://127.0.0.1:8092/path/getmoviesbyname?name=%E5%91%A8%E6%98%9F%E9%A9%B0

# getofftopn(/path/getofftopn)
http://127.0.0.1:8092/path/getofftopn

# getoptagtopn(/path/getoptagtopn)
http://127.0.0.1:8092/path/getoptagtopn

# getserialtopn(/path/getserialtopn)
http://127.0.0.1:8092/path/getserialtopn

# category(/servicepath/topn/category)
http://127.0.0.1:8092/servicepath/topn/category?category=001

# gameAppSearch(/path/gameAppSearch)
http://127.0.0.1:8092/path/gameAppSearch

# setvalidsearchitem(/path/setvalidsearchitem)
http://127.0.0.1:8092/path/setvalidsearchitem?mc=02000022000000012017041099262300&hdflag=1&searchkey=%E6%88%90%E9%BE%99&userid=59803030059

# getusersearchlist(/path/getusersearchlist)
http://127.0.0.1:8092/path/getusersearchlist?userid=59803030059

# searchchannel(/pathvoice/searchchannel)
http://127.0.0.1:8092/pathvoice/searchchannel?name=视&count=5

# searchschedule(/pathvoice/searchschedule)
http://127.0.0.1:8092/pathvoice/searchschedule?name=新闻联播&count=5

# searchvod(/pathvoice/searchvod)
http://127.0.0.1:8092/pathvoice/searchvod

# real-time(/api/v1/servicepath/channel/topn/real-time)
http://127.0.0.1:8092/api/v1/servicepath/channel/topn/real-time
http://127.0.0.1:8092/api/v1/servicepath/channel/topn/real-time?sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/channel/topn/real-time?sdonly=1&count=5&start=97
http://127.0.0.1:8092/api/v1/servicepath/channel/topn/real-time?sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/channel/topn/real-time?sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/channel/topn/real-time?sdonly=4

# real-time(/api/v1/servicepath/schedule/topn/real-time)
http://127.0.0.1:8092/api/v1/servicepath/schedule/topn/real-time
http://127.0.0.1:8092/api/v1/servicepath/schedule/topn/real-time?sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/schedule/topn/real-time?sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/schedule/topn/real-time?sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/schedule/topn/real-time?sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/schedule/topn/real-time?sdonly=4

# real-time(/api/v1/servicepath/schedule-tvod/topn/real-time)
http://127.0.0.1:8092/api/v1/servicepath/schedule-tvod/topn/real-time
http://127.0.0.1:8092/api/v1/servicepath/schedule-tvod/topn/real-time?sdonly=0&count=20&start=10
http://127.0.0.1:8092/api/v1/servicepath/schedule-tvod/topn/real-time?sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/schedule-tvod/topn/real-time?sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/schedule-tvod/topn/real-time?sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/schedule-tvod/topn/real-time?sdonly=4

# real-time(/api/v1/servicepath/video/topn/real-time)
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time?count=5&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time?count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time?count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time?count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time?count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time?count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time?count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time?count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time?count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time?count=5&column=001&feeType=1

# category(/api/v1/servicepath/video/topn/real-time/category)
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?count=5&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?category=/category_99948209
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?category=/category_99948209&count=5&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?category=/category_99948209&count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?category=/category_99948209&count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?category=/category_99948209&count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?category=/category_99948209&count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?category=/category_99948209&count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?category=/category_99948209&count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?category=/category_99948209&count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?category=/category_99948209&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?category=/category_99948209&count=5&column=001&feeType=1

# tags(/api/v1/servicepath/video/topn/real-time/tags)
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?count=5&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?dynamicTags=喜剧
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?dynamicTags=喜剧&count=5&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?dynamicTags=喜剧&count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?dynamicTags=喜剧&count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?dynamicTags=喜剧&count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?dynamicTags=喜剧&count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?dynamicTags=喜剧&count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?dynamicTags=喜剧&count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?dynamicTags=喜剧&count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?dynamicTags=喜剧&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?dynamicTags=喜剧&count=5&column=001&feeType=1

# offline(/api/v1/servicepath/video/topn/offline)
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?count=5&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=w
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=w&count=5&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=w&count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=w&count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=w&count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=w&count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=w&count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=w&count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=w&count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=w&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=w&count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=m
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=m&count=5&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=m&count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=m&count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=m&count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=m&count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=m&count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=m&count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=m&count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=m&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=m&count=5&column=001&feeType=1

# category(/api/v1/servicepath/video/topn/offline/category)
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?count=5&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=w
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=w&count=5&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=w&count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=w&count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=w&count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=w&count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=w&count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=w&count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=w&count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=w&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=w&count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=m
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=m&count=3&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=m&count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=m&count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=m&count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=m&count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=m&count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=m&count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=m&count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=m&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?dateType=m&count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&count=5&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=w
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=w&count=5&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=w&count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=w&count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=w&count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=w&count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=w&count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=w&count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=w&count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=w&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=w&count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=m
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=m&count=3&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=m&count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=m&count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=m&count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=m&count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=m&count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=m&count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=m&count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=m&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=m&count=5&column=001&feeType=1

# tags(/api/v1/servicepath/video/topn/offline/tags)
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?count=5&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=w
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=w&count=5&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=w&count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=w&count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=w&count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=w&count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=w&count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=w&count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=w&count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=w&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=w&count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=m
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=m&count=3&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=m&count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=m&count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=m&count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=m&count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=m&count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=m&count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=m&count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=m&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dateType=m&count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&count=5&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=w
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=w&count=5&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=w&count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=w&count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=w&count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=w&count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=w&count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=w&count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=w&count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=w&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=w&count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=m
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=m&count=3&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=m&count=5&sdonly=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=m&count=5&sdonly=2
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=m&count=5&sdonly=3
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=m&count=5&sdonly=4
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=m&count=5&sdonly=2&column=002
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=m&count=5&sdonly=2&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=m&count=5&column=001
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=m&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=m&count=5&column=001&feeType=1

# video(/api/v1/servicepath/schedule/recommend/video)
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend/video?userId=test001
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend/video?userId=test001&count=40&code=00000001000000070000000115830938
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend/video?userId=test001&count=42&channelCode=00000001000000050000000000001229
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend/video?userId=test001&count=42&channelCode=00000001000000050000000000001229&column=002&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend/video?userId=test001&count=42&channelCode=00000001000000050000000000001229&column=002&sdonly=1&cpid=02000031
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend/video?userId=test001&count=42&channelCode=00000001000000050000000000001229&column=002&sdonly=2&category=/category_74460927/category_52184965,/category_74460927
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend/video?userId=test001&count=42&channelCode=00000001000000050000000000001229&column=001,002&sdonly=3&category=/category_74460927/category_52184965,/category_74460927
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend/video?userId=test001&count=42&channelCode=00000001000000050000000000001229&column=001,002&sdonly=4&category=/category_74460927/category_52184965,/category_74460927&cpid=02000031http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend/video?userId=test999&count=42&channelCode=00000001000000050000000000001229&column=002&sdonly=0&category=/category_74460927/category_52184965,/category_74460927&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/schedule/recommend/video?userId=test999&count=42&channelCode=00000001000000050000000000001229&column=002&sdonly=0&category=/category_74460927/category_52184965,/category_74460927&feeType=0&virtualPackageIds=B

# similarity(/api/v1/servicepath/video/recommend/similarity)
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/similarity?userId=test001
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/similarity?userId=test001&start=2&count=43&code=02000000000000012019113099211298
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/similarity?userId=test001&start=2&count=42&code=02000000000000012019113099211298&column=002&sdonly=0
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/similarity?userId=test001&start=2&count=42&code=02000000000000012019113099211298&column=002&sdonly=1&cpid=02000031
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/similarity?userId=test001&start=2&count=42&code=02000000000000012019113099211298&column=002&sdonly=2&category=/category_74460927/category_52184965,/category_74460927
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/similarity?userId=test001&code=02000000000000012019113099211298&column=002&sdonly=3&cpid=02000031&category=/category_74460927/category_52184965,/category_74460927
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/similarity?userId=test001&start=2&count=42&code=02000000000000012019113099211298&column=002&sdonly=4&cpid=02000031&category=/category_74460927/category_52184965,/category_74460927
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/similarity?userId=test999&start=2&count=42&code=02000000000000012019113099211298&column=002&sdonly=0&cpid=02000031&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/similarity?userId=test999&start=2&count=42&code=02000000000000012019113099211298&column=002&sdonly=0&cpid=02000031&feeType=1&virtualPackageIds=B

# guess-like(/api/v1/servicepath/user/recommend/guess-like)
http://127.0.0.1:8092/api/v1/servicepath/user/recommend/guess-like?userId=test999&start=2&count=43
http://127.0.0.1:8092/api/v1/servicepath/user/recommend/guess-like?userId=test999&start=2&count=42&column=002&sdonly=0&cpid=02000031
http://127.0.0.1:8092/api/v1/servicepath/user/recommend/guess-like?userId=test999&start=2&count=42&column=002&sdonly=0&category=/category_74460927/category_52184965,/category_74460927
http://127.0.0.1:8092/api/v1/servicepath/user/recommend/guess-like?userId=test999&start=2&count=42&column=002&sdonly=0&cpid=02000031&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/user/recommend/guess-like?userId=test999&start=2&count=42&column=002&sdonly=0&cpid=02000031&feeType=1&virtualPackageIds=B

# most-popular(/api/v1/servicepath/video/recommend/most-popular)
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/most-popular?userId=test999&start=2&count=43
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/most-popular?userId=test999&start=2&count=42&column=002&sdonly=0&cpid=02000031
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/most-popular?userId=test999&start=2&count=42&column=002&sdonly=0&category=/category_74460927/category_52184965,/category_74460927
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/most-popular?userId=test999&start=2&count=42&column=002&sdonly=0&cpid=02000031&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/most-popular?userId=test999&start=2&count=42&column=002&sdonly=0&cpid=02000031&feeType=1&virtualPackageIds=B
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/most-popular?userId=test999&start=2&count=43&code=02000031000000012018091899764574

# similarity(/api/v1/servicepath/video/recommend/similarity)
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/similarity?userId=test999&start=2&count=42&code=02000000000000012019113099211298&column=002&sdonly=0&cpid=02000031&virtualPackages=A%7C0
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/similarity?userId=test999&start=2&count=42&code=02000000000000012019113099211298&column=002&sdonly=0&cpid=02000031&virtualPackages=B%7C1,C%7C1
http://127.0.0.1:8092/api/v1/servicepath/video/recommend/similarity?userId=test999&start=5&code=02000000000000012019113099211298&count=5&virtualPackages=B%7C1,C%7C1

# real-time(/api/v1/servicepath/video/topn/real-time)
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time?count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time?count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time?count=5&column=001&virtualPackageId=A
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time?count=5&column=001&virtualPackageId=B
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time?count=5&column=001&virtualPackageId=C
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time?count=5&column=001&virtualPackageId=D

# category(/api/v1/servicepath/video/topn/real-time/category)
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?category=/category_99948209&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?category=/category_99948209&count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?category=/category_99948209&count=5&column=001&virtualPackageId=A
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?category=/category_99948209&count=5&column=001&virtualPackageId=B
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?category=/category_99948209&count=5&column=001&virtualPackageId=C
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/category?category=/category_99948209&count=5&column=001&virtualPackageId=D

# tags(/api/v1/servicepath/video/topn/real-time/tags)
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?dynamicTags=喜剧&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?dynamicTags=喜剧&count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?dynamicTags=喜剧&count=5&column=001&virtualPackageId=A
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?dynamicTags=喜剧&count=5&column=001&virtualPackageId=B
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?dynamicTags=喜剧&count=5&column=001&virtualPackageId=C
http://127.0.0.1:8092/api/v1/servicepath/video/topn/real-time/tags?dynamicTags=喜剧&count=5&column=001&virtualPackageId=D

# offline(/api/v1/servicepath/video/topn/offline)
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=m&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=m&count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=m&count=5&virtualPackageId=A
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=m&count=5&virtualPackageId=B
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=m&count=5&virtualPackageId=C
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline?dateType=m&count=5&virtualPackageId=D

# category(/api/v1/servicepath/video/topn/offline/category)
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=m&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=m&count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=m&count=5&virtualPackageId=A
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=m&count=5&virtualPackageId=B
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=m&count=5&virtualPackageId=C
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/category?category=/category_99948209&dateType=m&count=5&virtualPackageId=D

# tags(/api/v1/servicepath/video/topn/offline/tags)
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=m&count=5&column=001&feeType=0
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=m&count=5&column=001&feeType=1
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=m&count=5&column=001&virtualPackageId=A
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=m&count=5&column=001&virtualPackageId=B
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=m&count=5&column=001&virtualPackageId=C
http://127.0.0.1:8092/api/v1/servicepath/video/topn/offline/tags?dynamicTags=犯罪&dateType=m&count=5&column=001&virtualPackageId=D

# guess-like(/api/v1/servicepath/user/recommend/guess-like)
http://127.0.0.1:8092/api/v1/servicepath/user/recommend/guess-like?userId=test999&start=2&count=42&column=002&sdonly=0&cpid=02000031&virtualPackages=B%7C1,C%7C1
http://127.0.0.1:8092/api/v1/servicepath/user/recommend/guess-like?userId=test999&start=2&count=42&column=002&sdonly=0&cpid=02000031&virtualPackages=B%7C1
http://127.0.0.1:8092/api/v1/servicepath/user/recommend/guess-like?userId=test999&start=2&count=42&column=002&sdonly=0&cpid=02000031&virtualPackages=B%7C
http://127.0.0.1:8092/api/v1/servicepath/user/recommend/guess-like?userId=test999&start=2&count=42&column=002&sdonly=0&cpid=02000031&virtualPackages=%7C1
