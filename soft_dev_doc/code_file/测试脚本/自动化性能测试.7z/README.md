# 警告
* 由于考虑到ssh免密不是经常能配置的，此脚本使用了 sshpass 免登录工具，需要在运行的服务器上安装此工具，才能运行此脚本
* 而且必须需要两台服务器相互配合才能进行自动化压测

# help
使用方式只需参照注释去修改对应的（setEnv.sh）配置文件即可。
其中测试URL的多个结果需要参照

* 例如: 
\# 标题(对应url)的形式划分多个接口
示例：
\# getnewtopn(/idp/<font color="red">getnewtopn</font>)
http://127.0.0.1:8092/path/getGuessSearch?q=赵&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=成龙&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=变形金刚&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=z&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=cl&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=CL&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=bxjg&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=BXJG&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=cl&count=300
\# getsimilaritems(/path/<font color="red">getsimilaritems</font>)
http://127.0.0.1:8092/path/getsimilaritems?mc=monggotv000000109854059327524518
http://127.0.0.1:8092/path/getsimilaritems?mc=monggotv000000109854059327524518&count=2

* 该脚本就会将红色字体部分解析出来当作关键字生成一个文件,并将从这个字体开始到下一个红色关键字內的URL归入一个文件
* 例如: 上述例子就会生成以下两个文件:
```sh
getnewtopn.txt
http://127.0.0.1:8092/path/getGuessSearch?q=赵&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=成龙&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=变形金刚&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=z&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=cl&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=CL&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=bxjg&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=BXJG&count=5
http://127.0.0.1:8092/path/getGuessSearch?q=cl&count=300
```
```sh
getsimilaritems.txt
http://127.0.0.1:8092/path/getsimilaritems?mc=monggotv000000109854059327524518
http://127.0.0.1:8092/path/getsimilaritems?mc=monggotv000000109854059327524518&count=2
```

* 关键字相同的情况下会将两块的URL合并到同一个文件下

# 安装
* 此压测脚本运行，需要两台服务器
    1. 一台安装有siege压测工具的服务器用于发送请求
    2. 一台安装有被测web服务的服务器
* 将此脚本安装到与要测试的WEB服务相同的服务器下即可

# 启动
`./start_pressure.sh`

# 关闭
`./stop_pressure.sh`

# 配置文件
```sh
# 需要与远程客户端配置SSH登录
# 远程用于发请求的客户端
# 客户端用户
CLIENT_USER="username"
# 客户端密码
CLIENT_PASSWORD="password"
# 客户端IP地址(装有siege压测工具的客户端)
CLIENT_IP="127.0.0.1"
# 远程端的siege路径
CLIENT_SIEGE_PATH="/your_siege_install_path/siege"
# 测试URL相对地址
TEST_URL_FILE="../you_urls_file.md"
# 分割后的文件夹
SPLIT_URLS_FLODER="urls"
# 发送进程数量
PROCESSES_NUM=16
# 单进程并发人数
CONCURRENT_NUMBER=10
# web服务部署地址
WEB_SERVICE_PATH="/your_web_app_path/isrs-service"
# web服务 进程名 
WEB_SERVICE_PROCESS_NAME="ServiceName"
# 并发日志生成路劲
FILE_SAVE_PATH="../testReport"
# 延迟时间，个人理解是第一次请求完毕到发送第二次请求的间隔
DELAY=0.3
# 压测时间 秒
STRESS_DURATION=100
# 最终压测报告名
TEST_REPORT_NAME="PRESSURE_TEST_REPORT"
```

* 此进程数量与但进程并发人数时累乘的效果，例如单进程支持10人并发请求，同时启动16个进程，单台服务器相当于同时会有160人进行请求。
* 延时时间越低，实际的每秒并发请求越高 按照以上配置16进程，10并发人数，0.3延迟时间 每秒时间大概是1000出头的并发量进行请求