import fun.fons.common.TopNHeap;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

public class TopNHeapTest {

    @Test
    void testConstructor() {
        // 正常初始化
        TopNHeap<Integer> heap = new TopNHeap<Integer>(10);
        assertEquals(0, heap.size());
        assertEquals(10, heap.getFunction().apply(10));

        // 自定义排序规则
        TopNHeap<Integer> customFuncHeap = new TopNHeap<Integer>(10, integer -> integer + 5);
        assertEquals(0, heap.size());
        assertEquals(15, customFuncHeap.getFunction().apply(10));
    }

    // 测试添加
    @Test
    void testAdd() {
        TopNHeap<String> heap = new TopNHeap<String>(10);

        heap.nothingAndInsert("1");
        assertEquals(1, heap.size());
        assertEquals("1", heap.getTopNList().get(0));

        heap.nothingAndInsert("2");
        assertEquals(2, heap.size());
        assertEquals("1", heap.getTopNList().get(1));
    }

    @Test
    void testRemove() {
        TopNHeap<String> heap = new TopNHeap<String>(10);

        heap.nothingAndInsert("1");
        heap.nothingAndInsert("2");
        assertTrue(heap.deleteMin());

        assertEquals(1, heap.size());
        assertEquals("2", heap.getTopNList().get(0));

        assertTrue(heap.deleteMin());
        assertEquals(0, heap.size());
    }


    @Test
    void testFull() {
        TopNHeap<String> heap = new TopNHeap<String>(10);

        heap.nothingAndInsert("1");
        heap.nothingAndInsert("2");
        heap.nothingAndInsert("3");
        heap.nothingAndInsert("4");
        heap.nothingAndInsert("5");
        heap.nothingAndInsert("6");
        heap.nothingAndInsert("7");
        heap.nothingAndInsert("8");
        heap.nothingAndInsert("9");
        heap.nothingAndInsert("10");
        heap.nothingAndInsert("11");
        heap.nothingAndInsert("12");
        heap.nothingAndInsert("13");

        assertEquals(10, heap.size());
        assertEquals("13", heap.getTopNList().get(0));

        assertTrue(heap.deleteMin());
        assertEquals(9, heap.size());
        assertEquals("13", heap.getTopNList().get(0));
    }

    @Test
    void testSyncInsertFull() {
        TopNHeap<Integer> heap = new TopNHeap<Integer>(100);
        int[] arr = new int[1000000];
        Random random = new Random();
        int max = 0;
        for (int i = 0; i < arr.length; i++) {
            int a = random.nextInt();
            arr[i] = a;
            if (a > max) {
                max = a;
            }
        }
        Arrays.stream(arr).parallel().forEach(heap::nothingAndInsert);
        assertEquals(100, heap.size());

        List<Integer> maxList = heap.getTopNList();
        assertEquals(max, maxList.get(0));
    }
}
