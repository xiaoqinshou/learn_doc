package fun.fons.common.pojo.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "模块信息")
public class ApplicationBase {
    @Schema(description = "名称")
    protected String name;
    @Schema(description = "版本")
    protected String version;
    @Schema(description = "地址")
    protected String address;
    @Schema(description = "端口")
    protected int port;
    @Schema(description = "状态")
    protected short status;
}
