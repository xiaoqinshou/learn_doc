package fun.fons.common.pojo.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Schema(description = "枚举字典")
public class EnumDict {

    @Schema(description = "枚举字典")
    private String code;

    @Schema(description = "枚举字典")
    private String name;
}
