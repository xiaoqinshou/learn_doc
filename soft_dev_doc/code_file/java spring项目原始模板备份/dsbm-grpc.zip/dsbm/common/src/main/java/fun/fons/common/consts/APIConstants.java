package fun.fons.common.consts;

public class APIConstants {
    /**
     * v1api基本路径
     */
    public static final String BASE_API_V1_PATH = "/api/v1";

    /**
     * v1 open api基本路径
     */
    public static final String OPEN_API_V1_PATH = "/api/open/v1";

    /**
     * v1auth基本路径
     */
    public static final String AUTH_API_PATH = "/auth/v1";

}
