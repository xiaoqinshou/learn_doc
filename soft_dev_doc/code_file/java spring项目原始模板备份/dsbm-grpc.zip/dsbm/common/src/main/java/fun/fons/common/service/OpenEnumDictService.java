package fun.fons.common.service;

import fun.fons.common.pojo.dto.EnumDict;

import java.util.List;

public interface OpenEnumDictService {

    List<EnumDict> findByType(String type);

    EnumDict findByCode(String type, String code);

    List<EnumDict> findChildNodesByCode(String type, String code);
}
