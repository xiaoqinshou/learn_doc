package fun.fons.common.consts;

public class SymbolConst {
    /**
     * 特殊符号定义
     */
    public static final String COMMA = ",";

    public static final String SLASH = "/";

    public static final String BACK_SLASH = "\\";

    public static final String DOUBLE_SLASH = "//";

    public static final String SPACE = " ";

    public static final String EMPTY = "";

    public static final String SEMICOLON = ";";

    public static final String QUESTION_MARK = "?";

    public static final String SQL_URL_SEPARATOR = "&";

    public static final String AT_SYMBOL = "@";

    public static final String OCTOTHORPE = "#";

    public static final String PERCENT_SIGN = "%";

    public static final String NEW_LINE_CHAR = "\n";

    public static final String COLON = ":";

    public static final String MINUS = "-";

    public static final String UNDERLINE = "_";

    public static final char CSV_HEADER_SEPARATOR = ':';

    public static final char DELIMITER_START_CHAR = '<';

    public static final char DELIMITER_END_CHAR = '>';

    public static final String PARENTHESES_START = "(";

    public static final String PARENTHESES_END = ")";

    public static final String SQUARE_BRACKET_START = "[";

    public static final String SQUARE_BRACKET_END = "]";


    public static final char ASSIGNMENT_CHAR = '=';

    public static final char DOLLAR_DELIMITER = '$';

    public static final String MYSQL_KEY_DELIMITER = "`";

    public static final String APOSTROPHE = "'";

    public static final String DOUBLE_QUOTES = "\"";

    public static final String DOT = ".";
}
