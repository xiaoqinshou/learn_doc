package fun.fons.umap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.cloud.client.discoverygrpc.EnableDiscoveryClient;

//@EnableDiscoveryClient
@SpringBootApplication
public class UMapApplication {
    public static void main(String[] args) {
        SpringApplication.run(UMapApplication.class, args);
    }
}
