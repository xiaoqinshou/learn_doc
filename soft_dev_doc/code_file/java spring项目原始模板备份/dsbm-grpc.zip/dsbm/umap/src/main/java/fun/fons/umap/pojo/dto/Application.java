package fun.fons.umap.pojo.dto;

import fun.fons.common.pojo.dto.ApplicationBase;
import fun.fons.umap.config.UMapConfiguration;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.stereotype.Component;

@Component
@Schema(description = "模块信息")
public class Application extends ApplicationBase {
    public Application(UMapConfiguration configuration) {
        this.name = configuration.getAppName();
        this.version = configuration.getAppVersion();
        this.address = configuration.getAddress();
        this.port = configuration.getPort();
        this.status = 0;
    }
}
