package fun.fons.umap.controller;

import fun.fons.common.consts.APIConstants;
import fun.fons.common.pojo.dto.ApplicationBase;
import fun.fons.umap.pojo.dto.Application;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "HeartbeatController", description = "心跳控制器")
@RestController
@Slf4j
@RequestMapping(value = APIConstants.OPEN_API_V1_PATH)
public class HeartbeatController {
    private final ApplicationBase application;

    public HeartbeatController(Application application) {
        this.application = application;
    }

    @Operation(summary = "模块心跳",description = "任意访问")
    @RequestMapping(value = "/ne-heartbeat", method = {RequestMethod.GET, RequestMethod.POST})
    public ResponseEntity<ApplicationBase> neHeartbeat(HttpServletRequest request) {
        log.debug("neHeartbeat clientIp: {} clientPort: {} application detail: {}",
                request.getRemoteAddr(), request.getRemotePort(), application);
        return ResponseEntity.ok(application);
    }
}
