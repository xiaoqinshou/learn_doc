package fun.fons.umap.controller;

import fun.fons.common.consts.APIConstants;
import fun.fons.common.pojo.dto.EnumDict;
import fun.fons.common.service.OpenEnumDictService;
import fun.fons.grpc.service.lib.EnumDictGrpc;
import fun.fons.grpc.service.lib.EnumReply;
import fun.fons.grpc.service.lib.EnumRequest;
import fun.fons.grpc.service.lib.EnumsReply;
import io.grpc.StatusRuntimeException;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = APIConstants.OPEN_API_V1_PATH + "/enum-dict")
public class TestEnumDictController {

    @GrpcClient("dsbm-cds")
    private EnumDictGrpc.EnumDictBlockingStub enumDictBlockingStub;

    @GetMapping("/{type}")
    public ResponseEntity type(@PathVariable String type) {
        try {
            EnumRequest enumRequest = EnumRequest.newBuilder().setType(type).build();
            final EnumsReply response = enumDictBlockingStub.findByType(enumRequest);
            return ResponseEntity.ok(response.getDataList());
        }catch (final StatusRuntimeException e){
            return ResponseEntity.badRequest().body(e);
        }
    }

    @GetMapping("/{type}/{code}")
    public ResponseEntity typeAndCode(@PathVariable String type, @PathVariable String code) {
        try {
            EnumRequest enumRequest = EnumRequest.newBuilder().setType(type).setCode(code).build();
            final EnumReply response = enumDictBlockingStub.findByCode(enumRequest);
            return ResponseEntity.ok(response);
        }catch (final StatusRuntimeException e){
            return ResponseEntity.badRequest().body(e);
        }
    }

    @GetMapping("/{type}/{code}/list")
    public ResponseEntity list(@PathVariable String type, @PathVariable String code) {
        try {
            EnumRequest enumRequest = EnumRequest.newBuilder().setType(type).setCode(code).build();
            final EnumsReply response = enumDictBlockingStub.findChildNodesByCode(enumRequest);
            return ResponseEntity.ok(response.getDataList());
        }catch (final StatusRuntimeException e){
            return ResponseEntity.badRequest().body(e);
        }
    }
}
