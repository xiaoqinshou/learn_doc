CREATE TABLE configuration_center.dictionary_enum
(
    id          INT PRIMARY KEY AUTO_INCREMENT COMMENT '主键自增ID',
    code        VARCHAR(50) UNIQUE NOT NULL COMMENT '唯一索引，代码',
    name        VARCHAR(50)        NOT NULL COMMENT '名称',
    description VARCHAR(1000) COMMENT '描述',
    sort_order  INT       DEFAULT 0 COMMENT '排序顺序',
    is_delete   tinyint(1) DEFAULT 0 COMMENT '状态, 0-正常, 1-删除',
    parent_code VARCHAR(50) COMMENT '父级代码',
    `type`      VARCHAR(50) COMMENT '类型',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间'
) COMMENT='枚举字典表';
