package fun.fons.cds.pojo.dto;

import fun.fons.cds.config.CdsConfiguration;
import fun.fons.common.pojo.dto.ApplicationBase;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.stereotype.Component;

@Component
@Schema(description = "模块信息")
public class Application extends ApplicationBase {
    public Application(CdsConfiguration configuration) {
        this.name = configuration.getAppName();
        this.version = configuration.getAppVersion();
        this.address = configuration.getAddress();
        this.port = configuration.getPort();
        this.status = 0;
    }
}
