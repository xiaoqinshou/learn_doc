package fun.fons.cds.controller;

import fun.fons.common.consts.APIConstants;
import fun.fons.cds.pojo.dto.PageSortDto;
import fun.fons.cds.pojo.vo.EnumDictionary;
import fun.fons.cds.service.AuthEnumDictService;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = APIConstants.AUTH_API_PATH + "/enum-dict")
public class AuthEnumDIctController {
    private final AuthEnumDictService authEnumDictService;

    public AuthEnumDIctController(AuthEnumDictService authEnumDictService) {
        this.authEnumDictService = authEnumDictService;
    }

    @GetMapping
    public ResponseEntity<Page<EnumDictionary>> list(PageSortDto<EnumDictionary> pageT) {
        return ResponseEntity.ok(authEnumDictService.findAll(pageT));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EnumDictionary> getEnumDictionaryById(@PathVariable Integer id) {
        return authEnumDictService.find(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public EnumDictionary createEnumDictionary(@RequestBody EnumDictionary enumDictionary) {
        return authEnumDictService.save(enumDictionary);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EnumDictionary> updateEnumDictionary(@PathVariable Integer id, @RequestBody EnumDictionary updatedEnumDictionary) {
        return ResponseEntity.of(authEnumDictService.update(id, updatedEnumDictionary));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEnumDictionary(@PathVariable Integer id) {
        authEnumDictService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
