package fun.fons.cds.dao;

import fun.fons.cds.pojo.vo.EnumDictionary;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EnumDictionaryRepository extends JpaRepository<EnumDictionary, Integer> {

}
