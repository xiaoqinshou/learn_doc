package fun.fons.cds.service.impl;

import fun.fons.cds.dao.EnumDictionaryRepository;
import fun.fons.cds.pojo.vo.EnumDictionary;
import fun.fons.common.pojo.dto.EnumDict;
import fun.fons.common.service.OpenEnumDictService;
import fun.fons.grpc.service.lib.EnumDictGrpc;
import fun.fons.grpc.service.lib.EnumReply;
import fun.fons.grpc.service.lib.EnumRequest;
import fun.fons.grpc.service.lib.EnumsReply;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;
import org.springframework.data.domain.Example;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@GrpcService
public class OpenEnumDictServiceImpl extends EnumDictGrpc.EnumDictImplBase implements OpenEnumDictService {

    private final EnumDictionaryRepository enumDictionaryRepository;

    public OpenEnumDictServiceImpl(EnumDictionaryRepository enumDictionaryRepository) {
        this.enumDictionaryRepository = enumDictionaryRepository;
    }

    public List<EnumDict> findByType(String type) {
        EnumDictionary enumDictionary = new EnumDictionary();
        enumDictionary.setType(type);
        enumDictionary.setIsDelete(false);
        return findAll(enumDictionary);
    }

    @Override
    public void findByType(EnumRequest request, StreamObserver<EnumsReply> responseObserver) {
        List<EnumReply> enumsDict = findByType(request.getType()).stream().map(i ->
                EnumReply.newBuilder()
                        .setName(i.getName())
                        .setCode(i.getCode())
                        .build()
        ).toList();
        final EnumsReply res = EnumsReply.newBuilder().addAllData(enumsDict).build();
        responseObserver.onNext(res);
        responseObserver.onCompleted();
    }

    public EnumDict findByCode(String type, String code) {
        EnumDictionary enumDictionary = new EnumDictionary();
        enumDictionary.setType(type);
        enumDictionary.setCode(code);
        Optional<EnumDictionary> optional = enumDictionaryRepository.findOne(Example.of(enumDictionary));
        return optional
                .map(i -> EnumDict.builder()
                        .code(i.getCode())
                        .name(i.getName())
                        .build())
                .orElse(null);
    }

    @Override
    public void findByCode(EnumRequest request, StreamObserver<EnumReply> responseObserver) {
        EnumDict enumDict = findByCode(request.getType(), request.getCode());
        final EnumReply res = EnumReply.newBuilder().setName(enumDict.getName()).setCode(enumDict.getCode()).build();
        responseObserver.onNext(res);
        responseObserver.onCompleted();
    }

    public List<EnumDict> findChildNodesByCode(String type, String code) {
        EnumDictionary enumDictionary = new EnumDictionary();
        enumDictionary.setType(type);
        enumDictionary.setParentCode(code);
        enumDictionary.setIsDelete(false);
        return findAll(enumDictionary);
    }

    @Override
    public void findChildNodesByCode(EnumRequest request, StreamObserver<EnumsReply> responseObserver) {
        List<EnumReply> enumsDict = findChildNodesByCode(request.getType(), request.getCode())
                .stream().map(i ->
                        EnumReply.newBuilder()
                                .setName(i.getName())
                                .setCode(i.getCode())
                                .build()
                ).toList();
        final EnumsReply res = EnumsReply.newBuilder().addAllData(enumsDict).build();
        responseObserver.onNext(res);
        responseObserver.onCompleted();
    }

    private List<EnumDict> findAll(EnumDictionary enumDictionary) {
        return enumDictionaryRepository
                .findAll(Example.of(enumDictionary))
                .stream()
                .sorted(Comparator.comparingInt(EnumDictionary::getSortOrder))
                .map(i -> EnumDict.builder().code(i.getCode()).name(i.getName()).build())
                .toList();
    }
}
