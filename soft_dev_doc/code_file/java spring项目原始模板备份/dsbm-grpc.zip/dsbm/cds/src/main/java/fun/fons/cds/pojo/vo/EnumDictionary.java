package fun.fons.cds.pojo.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "dictionary_enum")
@Schema(description = "枚举字典")
public class EnumDictionary {

    @Id
    @Schema(description = "主键ID， 默认不填")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Schema(description = "字典code")
    @Column(nullable = false)
    @NotBlank(message = "字典code，不能为空")
    private String code;

    @Schema(description = "字典名称")
    @Column(nullable = false)
    @NotBlank(message = "字典名称，不能为空")
    private String name;

    @Schema(description = "描述")
    @Column(length = 1000)
    private String description;

    @Schema(description = "排序值， 默认为0")
    @Column(name = "sort_order")
    private Integer sortOrder = 0;

    @Schema(description = "状态， 0=正常, 1=删除")
    @Column(name = "is_delete")
    private Boolean isDelete;

    @Column(name = "parent_code")
    @Schema(description = "父code")
    private String parentCode;

    @Schema(description = "类型")
    @NotBlank(message = "字典类型，不能为空")
    private String type;

    @Schema(description = "创建时间")
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Schema(description = "修改时间")
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    private String other;
}
