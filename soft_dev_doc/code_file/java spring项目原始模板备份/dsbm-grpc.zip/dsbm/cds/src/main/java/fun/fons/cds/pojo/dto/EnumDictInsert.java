package fun.fons.cds.pojo.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class EnumDictInsert {

    @Schema(description = "字典code")
    @NotBlank(message = "字典code，不能为空")
    private String code;

    @Schema(description = "字典名称")
    @NotBlank(message = "字典名称，不能为空")
    private String name;

    @Schema(description = "描述")
    private String description;

    @Schema(description = "排序值， 默认为0")
    private Integer sortOrder = 0;

    @Schema(description = "状态， 0=正常, 1=删除")
    private Boolean isDelete;

    @Schema(description = "父code")
    private String parentCode;

    @Schema(description = "类型")
    @NotBlank(message = "字典类型，不能为空")
    private String type;

    @Schema(description = "其他， 备用字段")
    private String other;
}
