package fun.fons.cds.config;

import fun.fons.common.consts.APIConstants;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import lombok.extern.slf4j.Slf4j;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
public class OpenApiConfiguration {

    private final CdsConfiguration cdsConfiguration;

    public OpenApiConfiguration(CdsConfiguration cdsConfiguration) {
        this.cdsConfiguration = cdsConfiguration;
    }

    @Bean
    public OpenAPI openApi() {
        String title = String.format("%s API", cdsConfiguration.getAppName());
        String description = String.format("%s interface description", cdsConfiguration.getAppDescription());
        String version = cdsConfiguration.getAppVersion();
        log.info("spring doc initialization..., title: {}, description: {}, version: {}", title, description, version);
        return new OpenAPI().info(new Info().title(title).description(description).version(version));
    }

    /**
     * auth 分组
     *
     * @return demo分组接口
     */
    @Bean
    public GroupedOpenApi siteApi() {
        return GroupedOpenApi.builder()
                .group("内部后台接口")
                .pathsToMatch(APIConstants.AUTH_API_PATH + "/**")
                .build();
    }

    /**
     * open 分组
     *
     * @return demo分组接口
     */
    @Bean
    public GroupedOpenApi openApis() {
        return GroupedOpenApi.builder()
                .group("对外全部开放接口")
                .pathsToMatch(APIConstants.OPEN_API_V1_PATH + "/**")
                .build();
    }
}
