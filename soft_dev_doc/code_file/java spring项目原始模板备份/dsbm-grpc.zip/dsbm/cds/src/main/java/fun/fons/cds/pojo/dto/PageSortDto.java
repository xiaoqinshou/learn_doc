package fun.fons.cds.pojo.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.data.domain.Sort;

@Data
@Schema(description = "分页排序")
public class PageSortDto<T> {
    @Schema(description = "当前页， 从0开始")
    private int page = 0;

    @Schema(description = "页大小， 默认： 10")
    private int size = 10;

    // todo 先给数组，前端传数组比较麻烦， 测试后再决定改字符串
    @Schema(description = "排序参数")
    private String[] sortNames = new String[0];

    @Schema(description = "顺序， ASC, DESC;")
    private Sort.Direction direction = Sort.Direction.ASC;

    @Schema(description = "筛选条件")
    private T filter;
}
