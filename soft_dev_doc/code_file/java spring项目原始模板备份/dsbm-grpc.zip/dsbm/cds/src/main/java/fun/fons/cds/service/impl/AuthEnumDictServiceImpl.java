package fun.fons.cds.service.impl;

import fun.fons.cds.dao.EnumDictionaryRepository;
import fun.fons.cds.pojo.dto.PageSortDto;
import fun.fons.cds.pojo.vo.EnumDictionary;
import fun.fons.cds.service.AuthEnumDictService;
import fun.fons.grpc.service.lib.EnumDictGrpc;
import net.devh.boot.grpc.server.service.GrpcService;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class AuthEnumDictServiceImpl implements AuthEnumDictService {

    private final EnumDictionaryRepository enumDictionaryRepository;

    public AuthEnumDictServiceImpl(EnumDictionaryRepository enumDictionaryRepository) {
        this.enumDictionaryRepository = enumDictionaryRepository;
    }

    @Override
    public Page<EnumDictionary> findAll(PageSortDto<EnumDictionary> pageT) {
        PageRequest pageRequest = PageRequest.of(pageT.getPage(), pageT.getSize(), pageT.getDirection(), pageT.getSortNames());
        return enumDictionaryRepository.findAll(Example.of(pageT.getFilter()), pageRequest);
    }

    @Override
    public Optional<EnumDictionary> find(Integer id) {
        return enumDictionaryRepository.findById(id);
    }

    public EnumDictionary save(EnumDictionary enumDictionary) {
        enumDictionary.setCreatedAt(LocalDateTime.now());
        enumDictionary.setUpdatedAt(LocalDateTime.now());
        return enumDictionaryRepository.save(enumDictionary);
    }

    @Override
    public Optional<EnumDictionary> update(Integer id, EnumDictionary enumDictionary) {
        Optional<EnumDictionary> optionalEnumDictionary = enumDictionaryRepository.findById(id);
        if (optionalEnumDictionary.isPresent()) {
            EnumDictionary existingEnumDictionary = optionalEnumDictionary.get();
            existingEnumDictionary.setCode(enumDictionary.getCode());
            existingEnumDictionary.setName(enumDictionary.getName());
            existingEnumDictionary.setDescription(enumDictionary.getDescription());
            existingEnumDictionary.setSortOrder(enumDictionary.getSortOrder());
            existingEnumDictionary.setIsDelete(enumDictionary.getIsDelete());
            existingEnumDictionary.setParentCode(enumDictionary.getParentCode());
            existingEnumDictionary.setType(enumDictionary.getType());
            existingEnumDictionary.setUpdatedAt(LocalDateTime.now());

            return Optional.of(enumDictionaryRepository.save(existingEnumDictionary));
        } else {
            return Optional.empty();
        }
    }

    public void delete(Integer id) {
        EnumDictionary enumDictionary = enumDictionaryRepository.findById(id).orElse(null);
        if (enumDictionary != null) {
            enumDictionary.setUpdatedAt(LocalDateTime.now());
            enumDictionary.setIsDelete(true);
            enumDictionaryRepository.save(enumDictionary);
        }
    }
}
