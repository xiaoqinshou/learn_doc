package fun.fons.cds.service;

import fun.fons.cds.pojo.dto.PageSortDto;
import fun.fons.cds.pojo.vo.EnumDictionary;
import org.springframework.data.domain.Page;

import java.util.Optional;

public interface AuthEnumDictService {

    Page<EnumDictionary> findAll(PageSortDto<EnumDictionary> sortDto);

    Optional<EnumDictionary> find(Integer id);

    EnumDictionary save(EnumDictionary enumDictionary);

    Optional<EnumDictionary> update(Integer id, EnumDictionary enumDictionary);

    void delete(Integer id);
}
