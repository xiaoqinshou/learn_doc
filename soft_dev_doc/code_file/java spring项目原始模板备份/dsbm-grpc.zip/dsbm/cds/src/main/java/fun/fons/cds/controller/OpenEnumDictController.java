package fun.fons.cds.controller;

import fun.fons.common.consts.APIConstants;
import fun.fons.common.pojo.dto.EnumDict;
import fun.fons.common.service.OpenEnumDictService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = APIConstants.OPEN_API_V1_PATH + "/enum-dict")
public class OpenEnumDictController {
    private final OpenEnumDictService openEnumDictService;

    public OpenEnumDictController(OpenEnumDictService openEnumDictService) {
        this.openEnumDictService = openEnumDictService;
    }

    @GetMapping("/{type}")
    public ResponseEntity<List<EnumDict>> type(@PathVariable String type) {
        return ResponseEntity.ok(openEnumDictService.findByType(type));
    }

    @GetMapping("/{type}/{code}")
    public ResponseEntity<EnumDict> typeAndCode(@PathVariable String type, @PathVariable String code) {
        return ResponseEntity.ok(openEnumDictService.findByCode(type, code));
    }

    @GetMapping("/{type}/{code}/list")
    public ResponseEntity<List<EnumDict>> list(@PathVariable String type, @PathVariable String code) {
        return ResponseEntity.ok(openEnumDictService.findChildNodesByCode(type, code));
    }
}
