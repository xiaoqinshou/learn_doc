/*==============================================================*/
/* Table: diagram_module_meta_table                             */
/*==============================================================*/
create table diagram_module_meta_table
(
   id                   int not null auto_increment,
   module_id            int not null,
   table_id             int not null,
   position             text not null,
   create_by            int not null,
   create_time          int not null,
   update_by            int not null,
   update_time          int not null,
   primary key (id)
);

/*==============================================================*/
/* Table: meta_table                                            */
/*==============================================================*/
create table meta_table
(
   id                   int not null auto_increment,
   name                 varchar(60) not null,
   description          text,
   property             text not null,
   project_id           int not null,
   create_by            int not null,
   create_time          int not null,
   update_by            int not null,
   update_time          int not null,
   primary key (id)
);

/*==============================================================*/
/* Table: module                                                */
/*==============================================================*/
create table module
(
   id                   int not null auto_increment,
   name                varchar(20) not null,
   description          text,
   avatar               varchar(255),
   project_id           int not null,
   `index`                int not null,
   create_by            int not null,
   create_time          int not null,
   update_by            int not null,
   update_time          int not null,
   primary key (id)
);

/*==============================================================*/
/* Table: organization                                          */
/*==============================================================*/
create table organization
(
   id                   int not null auto_increment,
   name                 varchar(50) not null,
   description          text,
   avatar               varchar(255),
   user_id              int not null,
   project_num          int not null,
   member_num           int not null,
   role_num             int not null,
   allow_create_project bool not null,
   member_permission    int not null,
   create_by            int not null,
   create_time          int not null,
   update_by            int not null,
   update_time          int not null,
   primary key (id)
);

/*==============================================================*/
/* Table: project                                               */
/*==============================================================*/
create table project
(
   id                   int not null auto_increment,
   name                 varchar(20) not null,
   description          text,
   pic                  varchar(255) not null,
   orz_id               int not null,
   user_id              int not null,
   visibility           bool not null,
   star_num             int not null,
   initial_org_id       int not null,
   create_by            int not null,
   create_time          int not null,
   update_by            int not null,
   update_time          int not null,
   primary key (id)
);

/*==============================================================*/
/* Table: relate_meta_table                                     */
/*==============================================================*/
create table relate_meta_table
(
   id                   int not null auto_increment,
   name                 varchar(20),
   module_id            int not null,
   table_id             int not null,
   to_table_id          int not null,
   type                 tinyint not null,
   create_by            int not null,
   create_time          int not null,
   update_by            int not null,
   update_time          int not null,
   primary key (id)
);

/*==============================================================*/
/* Table: user                                                  */
/*==============================================================*/
create table user
(
   id                   int not null auto_increment,
   email                varchar(50) not null,
   username             varchar(30) not null,
   password             varchar(32) not null,
   admin                tinyint not null,
   active               tinyint not null,
   name                 varchar(50),
   description          text,
   department           varchar(255),
   avatar               varchar(255),
   create_by            int not null,
   create_time          int not null,
   update_by            int not null,
   update_time          int not null,
   primary key (id)
);

