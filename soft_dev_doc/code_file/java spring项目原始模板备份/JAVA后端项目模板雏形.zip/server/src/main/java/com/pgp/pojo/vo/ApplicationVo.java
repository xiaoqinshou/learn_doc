package com.pgp.pojo.vo;

import com.pgp.config.PgpConfiguration;
import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
public class ApplicationVo {
    private String name;
    private String version;
    private short status;

    public ApplicationVo(PgpConfiguration configuration) {
        this.name = configuration.getAppName();
        this.version = configuration.getAppVersion();
        this.status = 0;
    }
}
