package com.pgp.common;

// 临时新建，后期重写该模块或删除该模块
public class TokenUtils {
    public Object refreshToken(String token) {
        return null;
    }
}
