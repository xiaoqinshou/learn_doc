/**
 * created on 2017年11月14日 下午4:47:56
 */
package com.pgp.controller;

import com.pgp.pojo.vo.ApplicationVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@Slf4j
public class DefaultController {
    @Autowired
    private ApplicationVo applicationVo;

    @RequestMapping(value = "/api/v1/ne-heartbeat", method = {RequestMethod.GET, RequestMethod.POST})
    public ResponseEntity neHeartbeat(HttpServletRequest request) {
        log.debug("neHeartbeat clientIp: {} clientPort: {} application detail: {}",
                request.getRemoteAddr(), request.getRemotePort(), applicationVo);
        return ResponseEntity.ok(applicationVo);
    }
}
