
const express = require('express');
const logger = require('./logger');

const { resolve } = require('path')
const app = express();
const argv = require('minimist')(process.argv.slice(2));
const setup = require('./middlewares/frontendMiddleware');

const port = parseInt(argv.port || process.env.PORT || '5002', 10);
const prettyHost = argv.host || process.env.HOST || 'localhost';

// take webpack.config.js as webpack-dev-middleware the base configuration file
setup(app, {
    outputPath: resolve(process.cwd(), 'build'),
    publicPath: '/'
});

// Use gzip compression
app.get('*.js', (req, res, next) => {
    req.url = req.url + '.gz'; // eslint-disable-line
    res.set('Content-Encoding', 'gzip')
    next()
});

// start app。
app.listen(port, async err => {
    if (err) {
        return logger.error(err.message)
    }
    logger.appStarted(port, prettyHost)
});