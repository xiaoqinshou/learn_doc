import { createHashHistory } from 'history'

const history = createHashHistory()
export default history
