import React from 'react'
import Helmet from 'react-helmet'

const App: React.FC = () => {
  return(
    <div>
      <Helmet
        titleTemplate="%s - Demo"
        defaultTitle="Demo Web Application"
        meta={[
          {
            name: 'description',
            content: 'Demo web application built for data visualization'
          }
        ]}
      />
      <h1>Hello World!!!</h1>
    </div>
  )
}

export default App;