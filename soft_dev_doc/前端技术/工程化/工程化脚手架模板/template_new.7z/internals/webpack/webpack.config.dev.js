const path = require('path');
const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
// 循环依赖检查插件
const CircularDependencyPlugin = require('circular-dependency-plugin');
// ts 检查插件
const ForkTsCheckerWebpackPlugin = require('fork-ts-checker-webpack-plugin');

module.exports = require('./webpack.config.base')({
    mode: "development",
    entry: {
        app: [
            'webpack-hot-middleware/client?reload=true',
            path.join(process.cwd(), 'app/app.tsx') // Start with js/app.js
        ],
    },
    output: {
        filename: '[name].js',
        chunkFilename: '[name].chunk.js',
    },

    optimization: {
        splitChunks: {
            chunks: 'all',
            maxAsyncRequests: 5,
            cacheGroups: {
                vendors: {
                    test: /[\\/]node_modules[\\/](?!antd|jquery|three|bootstrap-datepicker)(.[a-zA-Z0-9.\-_]+)[\\/]/,
                    name: 'vendor',
                    chunks: 'all'
                }
            }
        }
    },

    plugins: [
        new webpack.HotModuleReplacementPlugin(), // Tell webpack we want hot reloading
        new HtmlWebpackPlugin({
            filename: 'index.html',
            chunks: ['app', 'app~share', 'vendor'],
            inject: true,
            template: 'app/index.html'
        }),
        new CircularDependencyPlugin({
            exclude: /a\.js|node_modules/, // exclude node_modules
            failOnError: false // show a warning when there is a circular dependency
        }),
        new ForkTsCheckerWebpackPlugin()
    ],

    tsLoaders: [{
        loader: 'babel-loader',
        options: {
            plugins: ['react-hot-loader/babel']
        }
    }],
    // See https://webpack.js.org/configuration/devtool/#devtool
    devtool: 'eval-source-map',

    htmlWebpackPlugin: {
        files: {
            js: ['app.js'],
            chunks: {
                app: {
                    entry: 'app.js'
                }
            }
        }
    }
});