module.exports = {
    'primary-color': '#1B98E0',
    'table-padding-vertical': '10px',
    'table-padding-horizontal': '8px',
    'page-header-padding-vertical': '8px',
    'page-header-padding': '12px'
}